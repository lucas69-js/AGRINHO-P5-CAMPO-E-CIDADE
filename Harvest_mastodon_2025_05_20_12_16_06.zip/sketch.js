let cidadeX = 0;
let cidadeY = 0;
let campoX = 0;
let campoY = 0;

function setup() {
  createCanvas(800, 600);
  noStroke();
}

function draw() {
  background(220);

  // Desenhando o céu
  drawSky();

  // Desenhando o campo (natureza)
  drawField(campoX, campoY);

  // Desenhando a cidade (tecnologia)
  drawCity(cidadeX, cidadeY);
}

// Função para desenhar o céu
function drawSky() {
  let grad = drawingContext.createLinearGradient(0, 0, 0, height);
  grad.addColorStop(0, '#87CEEB'); // Céu azul claro
  grad.addColorStop(1, '#F0F8FF'); // Céu claro
  drawingContext.fillStyle = grad;
  rect(0, 0, width, height);
}

// Função para desenhar o campo (natureza)
function drawField(x, y) {
  fill(34, 139, 34); // Verde
  rect(x, height - 100, width, 100);

  // Adicionando árvores (simples)
  fill(139, 69, 19); // Tronco
  rect(100, height - 160, 20, 60); // Tronco
  fill(34, 139, 34); // Folhagem
  ellipse(110, height - 180, 60, 60);

  fill(139, 69, 19); // Tronco
  rect(500, height - 160, 20, 60); // Tronco
  fill(34, 139, 34); // Folhagem
  ellipse(510, height - 180, 60, 60);
}

// Função para desenhar a cidade (tecnologia)
function drawCity(x, y) {
  // Desenhando prédios
  fill(169, 169, 169); // Cor de concreto
  rect(50 + x, height - 250 - y, 100, 200);  // Prédio 1
  rect(200 + x, height - 300 - y, 120, 250);  // Prédio 2
  rect(400 + x, height - 200 - y, 150, 150);  // Prédio 3
  rect(600 + x, height - 280 - y, 80, 230);   // Prédio 4

  // Adicionando elementos de tecnologia (telas, antenas, etc.)
  fill(0, 255, 255); // Cor cibernética
  ellipse(50 + x + 50, height - 200 - y, 30, 30); // Telas de tecnologia no prédio 1
  ellipse(200 + x + 60, height - 250 - y, 30, 30); // Telas de tecnologia no prédio 2
  ellipse(400 + x + 75, height - 150 - y, 30, 30); // Telas de tecnologia no prédio 3

  // Adicionando antenas
  stroke(0);
  line(50 + x + 50, height - 250 - y, 50 + x + 50, height - 300 - y); // Antena do prédio 1
  line(200 + x + 60, height - 300 - y, 200 + x + 60, height - 350 - y); // Antena do prédio 2
  line(400 + x + 75, height - 200 - y, 400 + x + 75, height - 250 - y); // Antena do prédio 3
}

// Função para mover a cidade e o campo
function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    cidadeX -= 10;
    campoX -= 10;
  } else if (keyCode === RIGHT_ARROW) {
    cidadeX += 10;
    campoX += 10;
  }
}
